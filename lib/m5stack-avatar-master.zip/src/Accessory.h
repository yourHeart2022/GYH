// Copyright (c) Shinya Ishikawa. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full
// license information.

#ifndef ACCESSORY_H_
#define ACCESSORY_H_

// TODO(meganetaaan): Accessory

#endif  // ACCESSORY_H_
