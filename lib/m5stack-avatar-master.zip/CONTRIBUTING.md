* No much rules because this is so personal project.
* You should pass the CI process that runs when your PR is made. It builds all the example using the library.
* Take it easy and stay healthy. Thank you very much.
